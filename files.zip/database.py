"""
database.py
Thin SQLite persistence layer for the Supply Chain Fixer backend.

Tables:
  sessions  - single live simulation session (id=1), stores full agent
              state + running counters as JSON so the simulation can
              survive a server restart.
  events    - append-only log of everything that happens during a run
              (disruptions, fixer interventions, informational notes).
  runs      - saved run summaries a user has explicitly bookmarked,
              used for the "Run History" comparison table.
"""

import sqlite3
import json
import os
import time

DB_PATH = os.path.join(os.path.dirname(__file__), "supply_chain.db")

SCHEMA = """
CREATE TABLE IF NOT EXISTS sessions (
    id INTEGER PRIMARY KEY CHECK (id = 1),
    state_json TEXT NOT NULL,
    updated_at REAL NOT NULL
);

CREATE TABLE IF NOT EXISTS events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    day INTEGER NOT NULL,
    type TEXT NOT NULL,          -- 'info' | 'disrupt' | 'fix'
    message TEXT NOT NULL,
    created_at REAL NOT NULL
);

CREATE TABLE IF NOT EXISTS runs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    created_at REAL NOT NULL,
    days INTEGER NOT NULL,
    avg_service REAL NOT NULL,
    fixes INTEGER NOT NULL,
    stockouts INTEGER NOT NULL,
    notes TEXT
);
"""


def get_conn():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON;")
    return conn


def init_db():
    conn = get_conn()
    conn.executescript(SCHEMA)
    conn.commit()
    conn.close()


# ---------------- sessions (live simulation state) ----------------

def load_session():
    conn = get_conn()
    row = conn.execute("SELECT state_json FROM sessions WHERE id = 1").fetchone()
    conn.close()
    if row is None:
        return None
    return json.loads(row["state_json"])


def save_session(state_dict):
    conn = get_conn()
    conn.execute(
        """INSERT INTO sessions (id, state_json, updated_at)
           VALUES (1, ?, ?)
           ON CONFLICT(id) DO UPDATE SET state_json = excluded.state_json,
                                          updated_at = excluded.updated_at""",
        (json.dumps(state_dict), time.time()),
    )
    conn.commit()
    conn.close()


def clear_session():
    conn = get_conn()
    conn.execute("DELETE FROM sessions WHERE id = 1")
    conn.execute("DELETE FROM events")
    conn.commit()
    conn.close()


# ---------------- events (append-only log) ----------------

def add_event(day, event_type, message):
    conn = get_conn()
    conn.execute(
        "INSERT INTO events (day, type, message, created_at) VALUES (?, ?, ?, ?)",
        (day, event_type, message, time.time()),
    )
    conn.commit()
    conn.close()


def get_events(limit=200):
    conn = get_conn()
    rows = conn.execute(
        "SELECT day, type, message, created_at FROM events ORDER BY id DESC LIMIT ?",
        (limit,),
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


# ---------------- runs (saved summaries) ----------------

def save_run(days, avg_service, fixes, stockouts, notes=None):
    conn = get_conn()
    cur = conn.execute(
        """INSERT INTO runs (created_at, days, avg_service, fixes, stockouts, notes)
           VALUES (?, ?, ?, ?, ?, ?)""",
        (time.time(), days, avg_service, fixes, stockouts, notes),
    )
    conn.commit()
    run_id = cur.lastrowid
    conn.close()
    return run_id


def list_runs():
    conn = get_conn()
    rows = conn.execute(
        "SELECT id, created_at, days, avg_service, fixes, stockouts, notes "
        "FROM runs ORDER BY created_at DESC"
    ).fetchall()
    conn.close()
    return [dict(r) for r in rows]


def delete_run(run_id):
    conn = get_conn()
    conn.execute("DELETE FROM runs WHERE id = ?", (run_id,))
    conn.commit()
    conn.close()


# Ensure schema exists the moment this module is imported anywhere
# (simulation.py imports database before app.py gets a chance to call
# init_db() explicitly, so this guarantees tables always exist first).
init_db()
