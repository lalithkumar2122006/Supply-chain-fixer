"""
simulation.py
Orchestrates one shared simulation session. State is persisted to SQLite
after every mutating call (tick / trigger / reset) via database.py, so the
simulation survives a server restart and every event is durable, not just
held in memory.
"""

import database
from agents import (
    SupplierAgent, ManufacturerAgent, DistributorAgent, RetailerAgent,
    FixerAgent, random_disruption_roll,
)

DISRUPTION_TYPES = {"supplier_delay", "demand_spike", "distributor_breakdown", "quality_defect"}


class Simulation:
    def __init__(self):
        self.fixer = FixerAgent()
        self._load_or_init()

    # ---------------- persistence ----------------

    def _load_or_init(self):
        state = database.load_session()
        if state is None:
            self._reset_state()
        else:
            self.day = state["day"]
            self.fix_count = state["fix_count"]
            self.stockout_total = state["stockout_total"]
            self.service_sum = state["service_sum"]
            self.service_count = state["service_count"]
            self.service_history = state["service_history"]
            self.marker_history = state["marker_history"]
            self.pending = state["pending"]
            self.supplier = SupplierAgent.from_dict(state["supplier"])
            self.manufacturer = ManufacturerAgent.from_dict(state["manufacturer"])
            self.distributor = DistributorAgent.from_dict(state["distributor"])
            self.retailer = RetailerAgent.from_dict(state["retailer"])

    def _reset_state(self):
        self.day = 0
        self.fix_count = 0
        self.stockout_total = 0
        self.service_sum = 0
        self.service_count = 0
        self.service_history = []
        self.marker_history = []
        self.pending = {k: False for k in DISRUPTION_TYPES}
        self.supplier = SupplierAgent()
        self.manufacturer = ManufacturerAgent()
        self.distributor = DistributorAgent()
        self.retailer = RetailerAgent()

    def _persist(self):
        state = {
            "day": self.day,
            "fix_count": self.fix_count,
            "stockout_total": self.stockout_total,
            "service_sum": self.service_sum,
            "service_count": self.service_count,
            "service_history": self.service_history[-60:],
            "marker_history": self.marker_history[-60:],
            "pending": self.pending,
            "supplier": {**self.supplier.to_dict(), "disrupted_ticks": self.supplier.disrupted_ticks},
            "manufacturer": {**self.manufacturer.to_dict(), "defect_ticks": self.manufacturer.defect_ticks},
            "distributor": {**self.distributor.to_dict(), "breakdown_ticks": self.distributor.breakdown_ticks},
            "retailer": {**self.retailer.to_dict(), "demand_spike_ticks": self.retailer.demand_spike_ticks},
        }
        database.save_session(state)

    # ---------------- public API ----------------

    def reset(self):
        self._reset_state()
        database.clear_session()
        self._persist()
        database.add_event(0, "info", "Simulation reset.")

    def trigger(self, disruption_type):
        if disruption_type not in DISRUPTION_TYPES:
            raise ValueError(f"Unknown disruption type: {disruption_type}")
        self.pending[disruption_type] = True
        self._persist()

    def tick(self):
        self.day += 1
        events = []

        # occasionally trigger a disruption on its own, unless one is already pending
        if not any(self.pending.values()):
            auto = random_disruption_roll()
            if auto:
                self.pending[auto] = True

        supplier_was_disrupted = False
        distributor_was_disrupted = False

        if self.pending["supplier_delay"]:
            self.supplier.disrupt(3)
            events.append(("disrupt", "⚠ Disruption: Supplier hit by a shipping delay — output cut sharply."))
            self.pending["supplier_delay"] = False
        if self.pending["demand_spike"]:
            self.retailer.disrupt(2)
            events.append(("disrupt", "⚠ Disruption: Sudden demand spike at the Retailer."))
            self.pending["demand_spike"] = False
        if self.pending["distributor_breakdown"]:
            self.distributor.disrupt(3)
            events.append(("disrupt", "⚠ Disruption: Distributor vehicle breakdown — shipping capacity cut."))
            self.pending["distributor_breakdown"] = False
        if self.pending["quality_defect"]:
            self.manufacturer.disrupt(2)
            events.append(("disrupt", "⚠ Disruption: Quality defect at Manufacturer — part of production wasted."))
            self.pending["quality_defect"] = False

        # ---- 1. Supplier ----
        supplier_was_disrupted = self.supplier.is_disrupted()
        supplier_output = self.supplier.produce()

        # ---- 2. Manufacturer ----
        self.manufacturer.receive_raw(supplier_output)
        manufacturer_was_disrupted = self.manufacturer.is_disrupted()
        self.manufacturer.produce()
        raw_low = self.manufacturer.raw_is_low()

        # ---- 3. Distributor ----
        distributor_was_disrupted = self.distributor.is_disrupted()
        ship_capacity = self.distributor.current_ship_capacity()
        shipped = self.manufacturer.ship_finished(ship_capacity)
        self.distributor.receive(shipped)

        # ---- 4. Retailer ----
        demand = self.retailer.todays_demand()
        replen = min(self.distributor.inv, self.retailer.cap - self.retailer.inv,
                     round(self.distributor.ship_cap * 0.8))
        replen = max(0, replen)
        self.distributor.release(replen)
        self.retailer.receive(replen)
        fulfilled, shortfall = self.retailer.sell(demand)
        retailer_stockout = shortfall > 0
        if retailer_stockout:
            self.stockout_total += shortfall

        # ---- 5. Fixer ----
        actions, remaining_shortfall = self.fixer.inspect_and_fix(
            self.supplier, self.manufacturer, self.distributor, self.retailer,
            supplier_was_disrupted, distributor_was_disrupted, shortfall,
        )
        if remaining_shortfall < shortfall:
            fulfilled += (shortfall - remaining_shortfall)
        for action in actions:
            self.fix_count += 1
            events.append(("fix", "🛠 Fixer: " + action["message"]))

        service_level = round((fulfilled / demand) * 100) if demand else 100
        self.service_sum += service_level
        self.service_count += 1
        self.service_history.append(service_level)
        marker = "fix" if actions else ("disrupt" if any(e[0] == "disrupt" for e in events) else None)
        self.marker_history.append(marker)
        if len(self.service_history) > 60:
            self.service_history.pop(0)
            self.marker_history.pop(0)

        for etype, msg in events:
            database.add_event(self.day, etype, msg)

        self._persist()

        return self._build_state_dict(
            supplier_output=supplier_output,
            supplier_disrupted=supplier_was_disrupted,
            manufacturer_disrupted=manufacturer_was_disrupted,
            raw_low=raw_low,
            distributor_disrupted=distributor_was_disrupted,
            demand=demand,
            retailer_stockout=retailer_stockout,
            service_level=service_level,
            fix_targets=[a["target"] for a in actions],
            fix_messages=[a["message"] for a in actions],
        )

    def get_state(self, **flags):
        return self._build_state_dict(**flags)

    def _build_state_dict(self, supplier_output=None, supplier_disrupted=False,
                           manufacturer_disrupted=False, raw_low=None,
                           distributor_disrupted=False, demand=None,
                           retailer_stockout=False, service_level=None,
                           fix_targets=None, fix_messages=None):
        if supplier_output is None:
            supplier_output = self.supplier.capacity if not self.supplier.is_disrupted() else round(self.supplier.capacity * 0.25)
        if raw_low is None:
            raw_low = self.manufacturer.raw_is_low()
        if demand is None:
            demand = self.retailer.base_demand
        if service_level is None:
            service_level = round(self.service_sum / self.service_count) if self.service_count else 100
        avg_service = round(self.service_sum / self.service_count) if self.service_count else 100

        return {
            "day": self.day,
            "fix_count": self.fix_count,
            "stockout_total": self.stockout_total,
            "avg_service": avg_service,
            "service_level": service_level,
            "service_history": self.service_history,
            "marker_history": self.marker_history,
            "supplier": {
                "output": supplier_output,
                "capacity": self.supplier.capacity,
                "disrupted": supplier_disrupted,
            },
            "manufacturer": {
                "raw": round(self.manufacturer.raw),
                "raw_cap": self.manufacturer.raw_cap,
                "finished": round(self.manufacturer.finished),
                "fin_cap": self.manufacturer.fin_cap,
                "disrupted": manufacturer_disrupted,
                "raw_low": raw_low,
            },
            "distributor": {
                "inv": round(self.distributor.inv),
                "cap": self.distributor.cap,
                "disrupted": distributor_disrupted,
            },
            "retailer": {
                "inv": round(self.retailer.inv),
                "cap": self.retailer.cap,
                "demand": demand,
                "stockout": retailer_stockout,
            },
            "fix_targets": fix_targets or [],
            "fix_messages": fix_messages or [],
        }


# module-level singleton, backed by SQLite so it survives restarts
simulation = Simulation()
