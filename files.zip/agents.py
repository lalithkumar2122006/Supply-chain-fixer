"""
agents.py
Each class is one autonomous agent in the supply chain. Every agent only
knows about its own state and exposes a single `step()`-style method that
the Simulation orchestrator (simulation.py) calls once per day, in order:

    Supplier -> Manufacturer -> Distributor -> Retailer -> Fixer

The Fixer agent is the "college project" centerpiece: it never touches the
chain unless it detects a specific problem, and every action it takes is
returned as a human-readable reason so the event log doubles as an audit
trail of *why* the simulation behaved the way it did.
"""

import random


class SupplierAgent:
    def __init__(self, capacity=50):
        self.capacity = capacity
        self.disrupted_ticks = 0

    def is_disrupted(self):
        return self.disrupted_ticks > 0

    def disrupt(self, ticks=3):
        self.disrupted_ticks = ticks

    def produce(self):
        """Returns units of raw material shipped out this tick."""
        if self.is_disrupted():
            output = round(self.capacity * 0.25)
            self.disrupted_ticks -= 1
        else:
            output = self.capacity
        return output

    def to_dict(self):
        return {"capacity": self.capacity, "disrupted": self.is_disrupted()}

    @classmethod
    def from_dict(cls, d):
        obj = cls(capacity=d["capacity"])
        obj.disrupted_ticks = d.get("disrupted_ticks", 0)
        return obj


class ManufacturerAgent:
    def __init__(self, raw=100, raw_cap=220, finished=80, fin_cap=160, prod_rate=45):
        self.raw = raw
        self.raw_cap = raw_cap
        self.finished = finished
        self.fin_cap = fin_cap
        self.prod_rate = prod_rate
        self.defect_ticks = 0

    def is_disrupted(self):
        return self.defect_ticks > 0

    def disrupt(self, ticks=2):
        self.defect_ticks = ticks

    def receive_raw(self, incoming):
        self.raw = min(self.raw_cap, self.raw + incoming)

    def produce(self):
        rate = self.prod_rate
        if self.is_disrupted():
            rate = round(self.prod_rate * 0.4)
            self.defect_ticks -= 1
        produced = max(0, min(self.raw, rate, self.fin_cap - self.finished))
        self.raw -= produced
        self.finished += produced
        return produced

    def raw_is_low(self):
        return self.raw < self.raw_cap * 0.15

    def ship_finished(self, amount):
        amount = max(0, min(self.finished, amount))
        self.finished -= amount
        return amount

    def to_dict(self):
        return {
            "raw": self.raw, "raw_cap": self.raw_cap,
            "finished": self.finished, "fin_cap": self.fin_cap,
            "prod_rate": self.prod_rate,
        }

    @classmethod
    def from_dict(cls, d):
        obj = cls(raw=d["raw"], raw_cap=d["raw_cap"], finished=d["finished"],
                   fin_cap=d["fin_cap"], prod_rate=d["prod_rate"])
        obj.defect_ticks = d.get("defect_ticks", 0)
        return obj


class DistributorAgent:
    def __init__(self, inv=60, cap=180, ship_cap=45):
        self.inv = inv
        self.cap = cap
        self.ship_cap = ship_cap
        self.breakdown_ticks = 0

    def is_disrupted(self):
        return self.breakdown_ticks > 0

    def disrupt(self, ticks=3):
        self.breakdown_ticks = ticks

    def current_ship_capacity(self):
        cap = self.ship_cap
        if self.is_disrupted():
            cap = round(self.ship_cap * 0.3)
            self.breakdown_ticks -= 1
        return cap

    def receive(self, amount):
        amount = max(0, min(amount, self.cap - self.inv))
        self.inv += amount
        return amount

    def release(self, amount):
        amount = max(0, min(self.inv, amount))
        self.inv -= amount
        return amount

    def to_dict(self):
        return {"inv": self.inv, "cap": self.cap, "ship_cap": self.ship_cap}

    @classmethod
    def from_dict(cls, d):
        obj = cls(inv=d["inv"], cap=d["cap"], ship_cap=d["ship_cap"])
        obj.breakdown_ticks = d.get("breakdown_ticks", 0)
        return obj


class RetailerAgent:
    def __init__(self, inv=55, cap=130, base_demand=38):
        self.inv = inv
        self.cap = cap
        self.base_demand = base_demand
        self.demand_spike_ticks = 0

    def is_spiking(self):
        return self.demand_spike_ticks > 0

    def disrupt(self, ticks=2):
        self.demand_spike_ticks = ticks

    def todays_demand(self):
        demand = self.base_demand
        if self.is_spiking():
            demand += round(self.base_demand * 1.1)
            self.demand_spike_ticks -= 1
        return demand

    def receive(self, amount):
        amount = max(0, min(amount, self.cap - self.inv))
        self.inv += amount
        return amount

    def sell(self, demand):
        fulfilled = min(self.inv, demand)
        self.inv -= fulfilled
        shortfall = demand - fulfilled
        return fulfilled, shortfall

    def to_dict(self):
        return {"inv": self.inv, "cap": self.cap, "base_demand": self.base_demand}

    @classmethod
    def from_dict(cls, d):
        obj = cls(inv=d["inv"], cap=d["cap"], base_demand=d["base_demand"])
        obj.demand_spike_ticks = d.get("demand_spike_ticks", 0)
        return obj


class FixerAgent:
    """
    Watches the state of every other agent AFTER their daily step and
    applies one of four fixed interventions if, and only if, it detects
    the matching problem. Returns a list of (target, message) tuples that
    the Simulation records as 'fix' events.
    """

    def inspect_and_fix(self, supplier, manufacturer, distributor, retailer,
                         supplier_was_disrupted, distributor_was_disrupted,
                         retailer_shortfall):
        actions = []  # list of dicts: {target, message}

        if supplier_was_disrupted:
            boost = round(supplier.capacity * 0.35)
            manufacturer.receive_raw(boost)
            actions.append({
                "target": "supplier",
                "message": f"Switched Supplier to a backup source — recovered {boost} units of raw material.",
            })

        elif manufacturer.raw_is_low():
            emergency = round(manufacturer.raw_cap * 0.2)
            manufacturer.receive_raw(emergency)
            actions.append({
                "target": "manufacturer",
                "message": f"Expedited a raw-material shipment to Manufacturer (+{emergency} units) — buffer was critically low.",
            })

        if distributor_was_disrupted:
            boost = round(distributor.ship_cap * 0.4)
            moved = manufacturer.ship_finished(boost)
            distributor.receive(moved)
            actions.append({
                "target": "distributor",
                "message": f"Rerouted shipment through an alternate carrier — recovered {moved} units of throughput.",
            })

        remaining_shortfall = retailer_shortfall
        if retailer_shortfall > 0:
            pull = min(retailer_shortfall, distributor.inv)
            distributor.release(pull)
            retailer.receive(pull)
            remaining_shortfall = retailer_shortfall - pull
            actions.append({
                "target": "retailer",
                "message": f"Emergency-restocked Retailer from Distributor buffer (+{pull} units) to absorb demand spike.",
            })

        return actions, remaining_shortfall


def random_disruption_roll(chance=0.05):
    """Occasionally trigger a disruption on its own, mirroring real-world
    unpredictability. Returns one of the four disruption type strings, or
    None."""
    if random.random() >= chance:
        return None
    roll = random.random()
    if roll < 0.25:
        return "supplier_delay"
    if roll < 0.5:
        return "demand_spike"
    if roll < 0.75:
        return "distributor_breakdown"
    return "quality_defect"
