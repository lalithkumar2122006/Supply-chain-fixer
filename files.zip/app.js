(function(){
  const el = id => document.getElementById(id);

  const uiState = { running:false, speed:800, timer:null };

  const logEl = el('log');
  const fixerBanner = el('fixer-banner');
  const fixerText = el('fixer-text');
  const flows = [el('flow1'), el('flow2'), el('flow3')];

  function setBar(barId, pct, color){
    const bar = el(barId);
    bar.style.width = Math.max(0, Math.min(100, pct)) + '%';
    if(color) bar.style.background = color;
  }
  function setDot(id, level){
    el(id).className = 'status-dot' + (level==='warn' ? ' warn' : level==='bad' ? ' bad' : '');
  }
  function setNodeClass(nodeId, {fixing=false, disrupted=false}={}){
    const n = el(nodeId);
    n.classList.toggle('fixing', fixing);
    n.classList.toggle('disrupted', disrupted && !fixing);
  }

  // ---------------- API helpers ----------------
  async function api(path, opts){
    const res = await fetch(path, Object.assign({headers:{'Content-Type':'application/json'}}, opts||{}));
    if(!res.ok){
      const body = await res.json().catch(()=>({error:'Request failed'}));
      throw new Error(body.error || ('HTTP ' + res.status));
    }
    return res.json();
  }
  const getState   = () => api('/api/state');
  const doTick     = () => api('/api/tick', {method:'POST'});
  const doReset    = () => api('/api/reset', {method:'POST'});
  const doTrigger  = (type) => api('/api/trigger', {method:'POST', body: JSON.stringify({type})});
  const getEvents  = (limit=200) => api('/api/events?limit=' + limit);
  const getRuns    = () => api('/api/runs');
  const postRun    = () => api('/api/runs', {method:'POST'});
  const delRun     = (id) => api('/api/runs/' + id, {method:'DELETE'});

  // ---------------- Rendering ----------------
  function render(state){
    el('kpi-day').textContent = state.day;
    const svEl = el('kpi-service'), svBox = el('kpi-service-box');
    svEl.textContent = state.service_level + '%';
    svBox.className = 'kpi ' + (state.service_level>=90?'good':state.service_level>=70?'warn':'bad');
    el('kpi-fixes').textContent = state.fix_count;
    const soBox = el('kpi-stockout-box');
    el('kpi-stockout').textContent = state.stockout_total;
    soBox.className = 'kpi ' + (state.stockout_total===0?'good':state.stockout_total<40?'warn':'bad');

    const sup = state.supplier;
    el('m-supplier-out').textContent = sup.output + ' /day';
    setBar('bar-supplier-out', (sup.output/sup.capacity)*100, sup.disrupted?'var(--red)':'var(--teal)');
    setDot('dot-supplier', sup.disrupted?'bad':'ok');
    setNodeClass('node-supplier', {fixing: state.fix_targets.includes('supplier'), disrupted: sup.disrupted});
    el('status-supplier').textContent = sup.disrupted ? 'DELAYED' : 'OK';

    const man = state.manufacturer;
    el('m-man-raw').textContent = man.raw;
    setBar('bar-man-raw', (man.raw/man.raw_cap)*100, man.raw_low?'var(--amber)':'var(--teal)');
    el('m-man-fin').textContent = man.finished;
    setBar('bar-man-fin', (man.finished/man.fin_cap)*100, 'var(--teal)');
    setDot('dot-manufacturer', man.disrupted?'bad':man.raw_low?'warn':'ok');
    setNodeClass('node-manufacturer', {fixing: state.fix_targets.includes('manufacturer'), disrupted: man.disrupted||man.raw_low});
    el('status-manufacturer').textContent = man.disrupted ? 'QUALITY DEFECT' : man.raw_low ? 'LOW RAW STOCK' : 'OK';

    const dist = state.distributor;
    el('m-dist-inv').textContent = dist.inv;
    setBar('bar-dist-inv', (dist.inv/dist.cap)*100, dist.disrupted?'var(--red)':'var(--teal)');
    setDot('dot-distributor', dist.disrupted?'bad':'ok');
    setNodeClass('node-distributor', {fixing: state.fix_targets.includes('distributor'), disrupted: dist.disrupted});
    el('status-distributor').textContent = dist.disrupted ? 'BREAKDOWN' : 'OK';

    const ret = state.retailer;
    el('m-ret-inv').textContent = ret.inv;
    setBar('bar-ret-inv', (ret.inv/ret.cap)*100, ret.stockout?'var(--red)':'var(--teal)');
    el('m-ret-dem').textContent = ret.demand;
    setDot('dot-retailer', ret.stockout?'bad':'ok');
    setNodeClass('node-retailer', {fixing: state.fix_targets.includes('retailer'), disrupted: ret.stockout});
    el('status-retailer').textContent = ret.stockout ? 'STOCKOUT' : 'OK';

    const fixerActive = state.fix_messages.length > 0;
    fixerBanner.classList.toggle('active', fixerActive);
    fixerText.textContent = fixerActive ? state.fix_messages.join(' ') : 'Monitoring the chain — no issues detected.';

    flows.forEach(f => f.classList.toggle('paused', !uiState.running));

    drawChart(state.service_history, state.marker_history);
  }

  function renderLog(events){
    logEl.innerHTML = '';
    events.forEach(ev=>{
      const div = document.createElement('div');
      div.className = 'log-entry ' + ev.type;
      div.innerHTML = `<span class="day">Day ${String(ev.day).padStart(3,'0')}</span>${ev.message}`;
      logEl.appendChild(div);
    });
  }

  // ---------------- Chart ----------------
  const canvas = el('chart');
  const ctx = canvas.getContext('2d');
  function resizeCanvas(){
    canvas.width = canvas.clientWidth * devicePixelRatio;
    canvas.height = 150 * devicePixelRatio;
  }
  function drawChart(data, markers){
    resizeCanvas();
    const w = canvas.width, h = canvas.height;
    ctx.clearRect(0,0,w,h);
    if(!data || data.length < 2) return;
    const pad = 8*devicePixelRatio;
    const stepX = (w - pad*2) / Math.max(1,(data.length-1));

    ctx.strokeStyle = 'rgba(255,255,255,0.06)';
    ctx.lineWidth = 1;
    [0,25,50,75,100].forEach(pct=>{
      const y = h - pad - (pct/100)*(h-pad*2);
      ctx.beginPath(); ctx.moveTo(0,y); ctx.lineTo(w,y); ctx.stroke();
    });

    ctx.beginPath();
    ctx.strokeStyle = '#3FBFA6';
    ctx.lineWidth = 2*devicePixelRatio;
    data.forEach((v,i)=>{
      const x = pad + i*stepX;
      const y = h - pad - (v/100)*(h-pad*2);
      i===0 ? ctx.moveTo(x,y) : ctx.lineTo(x,y);
    });
    ctx.stroke();

    data.forEach((v,i)=>{
      const mark = markers[i];
      if(!mark) return;
      const x = pad + i*stepX;
      const y = h - pad - (v/100)*(h-pad*2);
      ctx.beginPath();
      ctx.fillStyle = mark==='fix' ? '#E8A33D' : '#E8615C';
      ctx.arc(x,y,3*devicePixelRatio,0,Math.PI*2);
      ctx.fill();
    });
  }
  window.addEventListener('resize', ()=> getState().then(s=>drawChart(s.service_history, s.marker_history)));

  // ---------------- Run History ----------------
  const historyBody = el('history-body');
  const historyTable = el('history-table');
  const historyEmpty = el('history-empty');
  const historyCount = el('history-count');

  async function refreshHistory(){
    try{
      const runs = await getRuns();
      historyCount.textContent = runs.length + (runs.length===1 ? ' run' : ' runs');
      if(runs.length === 0){
        historyEmpty.style.display = 'block';
        historyTable.style.display = 'none';
        return;
      }
      historyEmpty.style.display = 'none';
      historyTable.style.display = 'table';
      historyBody.innerHTML = '';
      runs.forEach(run=>{
        const d = new Date(run.created_at * 1000);
        const dateStr = d.toLocaleDateString() + ' ' + d.toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'});
        const tr = document.createElement('tr');
        const color = run.avg_service>=90 ? 'var(--green)' : run.avg_service>=70 ? 'var(--amber)' : 'var(--red)';
        tr.innerHTML = `
          <td>${dateStr}</td>
          <td>${run.days}</td>
          <td style="color:${color}">${Math.round(run.avg_service)}%</td>
          <td>${run.fixes}</td>
          <td>${run.stockouts}</td>
          <td><button class="del-run" data-id="${run.id}">✕ Delete</button></td>
        `;
        historyBody.appendChild(tr);
      });
      historyBody.querySelectorAll('.del-run').forEach(btn=>{
        btn.addEventListener('click', async ()=>{
          await delRun(btn.dataset.id);
          refreshHistory();
        });
      });
    }catch(err){
      el('storage-status').textContent = 'DB: ' + err.message;
      el('storage-status').className = 'storage-status mono err';
    }
  }

  // ---------------- Tick loop ----------------
  async function step(){
    const state = await doTick();
    render(state);
    const events = await getEvents(200);
    renderLog(events);
  }

  const btnPlay = el('btn-play');
  function setRunning(run){
    uiState.running = run;
    btnPlay.textContent = run ? '⏸ Pause' : '▶ Start';
    if(run){
      uiState.timer = setInterval(()=>{ step().catch(console.error); }, uiState.speed);
    } else {
      clearInterval(uiState.timer);
    }
    flows.forEach(f => f.classList.toggle('paused', !run));
  }
  btnPlay.addEventListener('click', ()=> setRunning(!uiState.running));
  el('btn-step').addEventListener('click', ()=>{ if(!uiState.running) step().catch(console.error); });
  el('btn-reset').addEventListener('click', async ()=>{
    setRunning(false);
    const state = await doReset();
    render(state);
    renderLog(await getEvents(200));
  });
  el('speed').addEventListener('input', e=>{
    uiState.speed = 1800 - parseInt(e.target.value);
    if(uiState.running){ clearInterval(uiState.timer); uiState.timer = setInterval(()=>{ step().catch(console.error); }, uiState.speed); }
  });

  el('btn-supplier-delay').addEventListener('click', ()=> doTrigger('supplier_delay').catch(console.error));
  el('btn-demand-spike').addEventListener('click', ()=> doTrigger('demand_spike').catch(console.error));
  el('btn-distributor-breakdown').addEventListener('click', ()=> doTrigger('distributor_breakdown').catch(console.error));
  el('btn-quality-defect').addEventListener('click', ()=> doTrigger('quality_defect').catch(console.error));

  el('btn-save-run').addEventListener('click', async ()=>{
    try{
      await postRun();
      refreshHistory();
    }catch(err){
      alert(err.message);
    }
  });

  // ---------------- Init ----------------
  (async function init(){
    try{
      const state = await getState();
      render(state);
      renderLog(await getEvents(200));
      el('storage-status').textContent = 'DB: connected';
      el('storage-status').className = 'storage-status mono ok';
    }catch(err){
      el('storage-status').textContent = 'DB: unavailable';
      el('storage-status').className = 'storage-status mono err';
    }
    refreshHistory();
  })();
})();
