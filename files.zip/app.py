"""
app.py
Flask REST API + static frontend host for the Supply Chain Fixer.

Run with:  python app.py
Then open: http://127.0.0.1:5000
"""

from flask import Flask, jsonify, request, render_template

import database
from simulation import simulation, DISRUPTION_TYPES

app = Flask(__name__)


@app.route("/")
def index():
    return render_template("index.html")


@app.route("/api/state")
def api_state():
    return jsonify(simulation.get_state())


@app.route("/api/tick", methods=["POST"])
def api_tick():
    state = simulation.tick()
    return jsonify(state)


@app.route("/api/reset", methods=["POST"])
def api_reset():
    simulation.reset()
    return jsonify(simulation.get_state())


@app.route("/api/trigger", methods=["POST"])
def api_trigger():
    body = request.get_json(silent=True) or {}
    disruption_type = body.get("type")
    if disruption_type not in DISRUPTION_TYPES:
        return jsonify({"error": f"type must be one of {sorted(DISRUPTION_TYPES)}"}), 400
    simulation.trigger(disruption_type)
    return jsonify({"ok": True})


@app.route("/api/events")
def api_events():
    limit = request.args.get("limit", default=100, type=int)
    return jsonify(database.get_events(limit=limit))


@app.route("/api/runs", methods=["GET"])
def api_list_runs():
    return jsonify(database.list_runs())


@app.route("/api/runs", methods=["POST"])
def api_save_run():
    state = simulation.get_state()
    if state["day"] == 0:
        return jsonify({"error": "Run the simulation for at least one day before saving."}), 400
    run_id = database.save_run(
        days=state["day"],
        avg_service=state["avg_service"],
        fixes=state["fix_count"],
        stockouts=state["stockout_total"],
    )
    return jsonify({"id": run_id})


@app.route("/api/runs/<int:run_id>", methods=["DELETE"])
def api_delete_run(run_id):
    database.delete_run(run_id)
    return jsonify({"ok": True})


if __name__ == "__main__":
    database.init_db()
    app.run(debug=True, port=5000)
